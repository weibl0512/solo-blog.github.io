title: SpringBoot  学习!!!
date: '2020-08-28 20:03:46'
updated: '2020-08-28 20:03:46'
tags: [Java学习]
permalink: /articles/2020/08/28/1598616226551.html
---
# SpringBoot学习


###  SpringBoot编写主程序

> ##### @SpringBootApplication 标注这个主程序是一个SpringBoot程序
>
> ##### 在主程序的main方法中使用SpringBootApplication.run(类的全名.class,args[main方法参数]);


### SpringBoot-yml配置文件的使用

> ##### YAML (YAML Ain't a Markup Language)YAML不是一种标记语言，通常以.yml为后缀的文件，是一种直观的能够被电脑识别的数据序列化格式，并且容易被人类阅读，容易和脚本语言交互的，可以被支持YAML库的不同的编程语言程序导入，一种专门用来写配置文件的语言
>
> ##### YAML：以数据为中心，比json、xml等更适合做配置文件;
>
> ##### ：YAML语法： 1、基本语法 k:(空格)v：表示一对键值对（空格必须有以空格的缩进来控制层级关系；只要是左对齐的一列数据，都是同一个层级的

> ##### YML与Properties的读取优先级:  正常的情况是先加载yml，接下来加载properties文件。如果相同的配置存在于两个文件中,文件配置也会互补。最后会使用properties中的配置。最后读取的优先集最高。

```yml
YAML 配置例：
server: 
    port: 8080 //修改端口号
  
    复合形式:
    map:
        key: value
        key: value
        key: value
    list:
        - 值
        - 值
        - 值
    对象:
        属性(key): 值(value)
    数组:[值,值,值,值]
# "" 与''的区别
	""会解析转义字符
	''不会解析转义字符
  
XML:
<server>
    <port>8081</port>
</server>

```

> ##### 将yml和properties内配置的数据读取出来
>
> ##### 第一种方式: 将配置文件中配置的每一个属性的值(所有能配置的都配置)，映射到这个组件中@ConfigurationProperties：告诉SpringBoot将本类中的所有属性和配置文件中相关的配置进行绑定;prefix = "person"：配置文件中哪个下面的所有属性进行一一映射只有这个组件是容器中的组件(@Component(["id"]--可以省略不写,如果不写默认将以全类名命名id,只不过首字母小写))，才能容器提供的@ConfigurationProperties功能;

> ##### 第二种方式: @Value("$")  这个只能单独获取一个属性名,在只需要获取一个值的时候,比如删除需要的id {配置文件的属性(key)}

```
比如: 
@Value("${配置文件的属性(key)}") 在里面写${spel}表达式
private String name;
```

> ##### 区别: @ConfigurationProperties只能全部加载,不能指定单个属性进行加载,它还可以进行数据校验(比如在一个属性上定义一个注解@Email 那么这个属性只能是Eamil格式)
>
> ##### @Value("$") 这个等同于 <bean value=""></bean> {配置文件的属性(key)}


### @PropertySource , @ImportResource , @Bean 注解

> ##### @PropertySouce(value=) : 读取指定的配置文件,可加载多个(上面的@ConfigurationProperties只能读取全局的配置文件,如果全把配置信息写在全局配置文件会影响可读性,可维护性) {classpath:[配置文件名称]}

> ##### @ImportResource(locations=) : 加载Spring配置文件   因为在SpringBoot中没有Spring配置文件,自己写的也不能自动生效,如果想要使用Spring配置文件,则将@ImportResource注解添加到Spring标注的类上,也可以同时导入多个Spring配置文件(不过这种方式SpringBoot不推荐使用) {classpath:[配置文件名称}
>
> ##### Spring推荐使用配置类代替配置文件
>
> ##### @Configuration : 标明一个类是配置类
>
> ##### @Bean : 是用来代替之前配置文件的Bean标签的  它可以定义在方法上,将方法的返回值添加到容器中,默认的Id是方法的名字


### 配置文件占位符

> ##### 随机数  ${random.*}  获取之前配置的值 : $ {前面配置的key [:指定默认值(如果找不到)] }


### Profile(SpringBoot的多环境支持)

> ##### 在编写主配置文件的时候,可以在文件名后,文件类型前加一个标识 例:application-.properties/yml {profile(这是名字,不固定)}


#### 如何使用Profile

> ##### (1) 在主配置文件中(默认生成的主配置文件 application.properties)设置激活,通过spring.profiles.active=,来进行配置多环境 {配置的标识}
>
> ![application-dev.properties](https://b3logfile.com/file/2020/08/solofetchupload8798145191905936526-3a424604.png)![application.properties](https://b3logfile.com/file/2020/08/solofetchupload6212364553624650302-3914c189.png)
>
> ##### (2)YML的配置方式 在yml配置文件中的 - - -  符号(自己取消空格) 代表一个文档块,spring: profiles: active: 标识---用来激活激活  spring: profiles: 标识---用来定义
>
> ![在这里插入图片描述](https://b3logfile.com/file/2020/08/solofetchupload3990695435988565512-4d9aebb1.png)


#### SpringBoot配置文件加载顺序

> ##### SpringBoot配置文件依次从
>
> ##### 当前项目根目录/config/ ---优先级最大
>
> ##### 当前项目根目录 ---排行老二
>
> ##### 类路径(resources)/config/ ---老三
>
> ##### 类路径 --- 老四
>
> ##### *(加载时配置会都读取生效,如果有重复的则按照优先级(覆盖优先级低的)执行)
>
> ##### 也可以指定使用外部的配置文件(在运维的时候使用,算是一种补救措施)
>
> ##### server.cinfig.location = 外部配置文件全地址
